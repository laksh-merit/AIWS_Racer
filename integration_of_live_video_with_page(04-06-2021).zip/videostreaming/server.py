# USAGE
# python server.py --prototxt MobileNetSSD_deploy.prototxt --model MobileNetSSD_deploy.caffemodel --montageW 2 --montageH 2
# import the necessary packages
from imutils import build_montages
from datetime import datetime
import numpy as np
import imagezmq
import argparse


from imutils.video import VideoStream
from flask import Response
from flask import Flask
from flask import render_template
import threading
import argparse
import datetime
import imutils
import time
import cv2

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-p", "--prototxt", required=False,
   help="path to Caffe 'deploy' prototxt file")
ap.add_argument("-m", "--model", required=False,
   help="path to Caffe pre-trained model")
ap.add_argument("-c", "--confidence", type=float, default=0.2,
   help="minimum probability to filter weak detections")
ap.add_argument("-mW", "--montageW", required=False, type=int,
   help="montage frame width")
ap.add_argument("-mH", "--montageH", required=False, type=int,
   help="montage frame height")
args = vars(ap.parse_args())
# initialize the ImageHub object
imageHub = imagezmq.ImageHub()
print(type(imageHub))







# start looping over all the frames
while True:
   # receive RPi name and frame from the RPi and acknowledge
   # the receipt
   (rpiName, frame) = imageHub.recv_image()
   frame1 = frame
   imageHub.send_reply(b'OK')

   cv2.imshow("Home pet location monitor", frame1)
   # detect any kepresses
   key = cv2.waitKey(1) & 0xFF
   # if current time *minus* last time when the active device check
   # was made is greater than the threshold set then do a check

   # if the `q` key was pressed, break from the loop
   if key == ord("q"):
      break
# do a bit of cleanup
cv2.destroyAllWindows()


